# Arcadia Black — Landing (ES, estática)

## Opción A — Publicar en Vercel (con repositorio)
1. Crea un **repositorio privado** y sube estos archivos.
2. Entra a **Vercel** → **Nuevo Proyecto** → **Importar desde Git** → elige tu repo.
3. Framework: **Otros** (sitio estático). Sin comando de build. Directorio de salida: **/** (raíz).
4. Publica. Tu página quedará en una dirección pública.

## Opción B — Publicar en Vercel (subida directa)
1. Comprime el contenido (ya está en este ZIP).
2. Entra a **Vercel** → **Nuevo Proyecto** → **Subir** (si aparece la opción) y selecciona el ZIP.
3. Publica.

## Opción C — Publicar en Render (estático, opcional)
1. Crea un **servicio web** estático en Render y sube este contenido.
2. O usa el `Dockerfile` y `render.yaml` incluidos (servido con Nginx).

## Personalización
- Cambia el correo en el HTML (busca `arcadiablackultra@gmail.com` si alguna vez quieres otro).
- Cambia el número de WhatsApp (busca `573006256212`).

## Botón “Deploy with Vercel” para tu README (cuando tengas repo)
Copia esto y reemplaza `REPO_URL` por la URL de tu repositorio:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=REPO_URL)
